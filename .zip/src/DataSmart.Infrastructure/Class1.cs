﻿namespace DataSmart.Infrastructure;

public class Class1
{

}
