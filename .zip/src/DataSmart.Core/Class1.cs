﻿namespace DataSmart.Core;

public class Class1
{

}
