import React from 'react';
import UploadExcel from './components/UploadExcel';  // ← Así exactamente
import 'bootstrap/dist/css/bootstrap.min.css';



function App() {
  return (
    <div className="App">
      <UploadExcel />
    </div>
  );
}

export default App;